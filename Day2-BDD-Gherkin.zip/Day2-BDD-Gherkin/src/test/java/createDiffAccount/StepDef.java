package createDiffAccount;


import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.cap.dao.IAccountDao;
import org.cap.model.Account;
import org.cap.model.Address;
import org.cap.model.Customer;
import org.cap.service.AccountServiceImpl;
import org.cap.service.IAccountService;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {
	private Customer customer;
	private IAccountService accountService;
	private Account account;

	
	@Mock
	private IAccountDao accountDao;
	
	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		accountService=new AccountServiceImpl(accountDao);
		
	}
	
	
	
	
	@Given("^Customer Details$")
	public void customer_Details() throws Throwable {
		Address address=new Address("23 North avvenue","Chennai");
		this.customer=new Customer("Tom", "Jerry", address);
	}

	@When("^For valid Customer with minimum opening balance (\\d+)$")
	public void for_valid_Customer_with_minimum_opening_balance(int balance) throws Throwable {
	    assertNotNull(this.customer);
	    
	    account=new Account();
	    
	    account.setCustomer(this.customer);
	    account.setOpeningBalance(balance);
	    
	    Mockito.when(accountDao.createAccount(account)).thenReturn(true);
	    
	    this.account=accountService.createAccount(this.customer, balance);
	    
	    Mockito.verify(accountDao).createAccount(account);
	    
	    
	    
	    
	}

	@Then("^Create new savings$")
	public void create_new_savings() throws Throwable {
	    assertEquals("savings", this.account.getAccountType());
	}

	@Then("^Create new current$")
	public void create_new_current() throws Throwable {
		 assertEquals("current", this.account.getAccountType());
	}

	@Then("^Create new rd$")
	public void create_new_rd() throws Throwable {
		 assertEquals("rd", this.account.getAccountType());
	}

	@Then("^Create new fd$")
	public void create_new_fd() throws Throwable {
		 assertEquals("fd", this.account.getAccountType());
	}



}
